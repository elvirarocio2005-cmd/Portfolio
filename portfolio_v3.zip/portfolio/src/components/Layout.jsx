import { NavLink, Link, useLocation } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { siteConfig as c } from '../data/siteConfig.js'
const B = import.meta.env.BASE_URL
const DEV = import.meta.env.DEV
const LINKS = [['/projects', 'Proyectos'], ['/about', 'Sobre mí'], ['/contact', 'Contacto']]

function Footer() {
  return (
    <footer className="foot">
      <div className="foot-grid">
        <div><p className="foot-name">{c.name}</p><p className="foot-sub">{c.brand}</p></div>
        <div><h2 className="label">Navegación</h2>
          <Link to="/">Inicio</Link>{LINKS.map(([to, l]) => <Link key={to} to={to}>{l}</Link>)}</div>
        <div><h2 className="label">Contacto</h2>
          {c.email && <a href={`mailto:${c.email}`}>{c.email}</a>}{c.location && <span>{c.location}</span>}</div>
        <div><h2 className="label">Redes</h2>
          {c.links.map((l) => <a key={l.url} href={l.url} target="_blank" rel="noreferrer">{l.label} ↗</a>)}
          {!c.links.length && DEV && <span className="hint">Añade tus redes en siteConfig.js</span>}</div>
      </div>
      <div className="foot-end"><span>© {new Date().getFullYear()} {c.name}</span>
        <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>Volver arriba ↑</button></div>
    </footer>
  )
}

export default function Layout({ children }) {
  const { pathname } = useLocation()
  const [open, setOpen] = useState(false); const [sc, setSc] = useState(false)
  useEffect(() => { window.scrollTo(0, 0); setOpen(false); document.title = `${c.name} — Portfolio` }, [pathname])
  useEffect(() => {
    const f = () => setSc(window.scrollY > 12); f()
    window.addEventListener('scroll', f, { passive: true }); return () => window.removeEventListener('scroll', f)
  }, [])
  return (
    <>
      <a className="skip" href="#main">Saltar al contenido</a>
      <header className={`head${sc ? ' sc' : ''}${open ? ' open' : ''}`}>
        <Link to="/" className="logo" aria-label={`${c.brand}: ir al inicio`}>
          <img src={`${B}logo.png`} alt="" className="logo-mark" /><img src={`${B}brand.png`} alt={c.brand} className="logo-word" />
        </Link>
        <button className="burger" aria-expanded={open} aria-controls="nav" aria-label="Menú" onClick={() => setOpen(!open)}><span /><span /></button>
        <nav id="nav" aria-label="Principal">{LINKS.map(([to, l]) => <NavLink key={to} to={to}>{l}</NavLink>)}</nav>
      </header>
      <main id="main"><div key={pathname} className="page">{children}</div></main>
      <Footer />
    </>
  )
}
