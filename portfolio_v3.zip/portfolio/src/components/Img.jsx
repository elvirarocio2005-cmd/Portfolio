import { useState, useEffect } from 'react'
const DEV = import.meta.env.DEV
const RATIO = { vertical: '4 / 5', horizontal: '3 / 2', square: '1 / 1' }
export const url = (src) => /^https?:|^\//.test(src) ? src : `${import.meta.env.BASE_URL}projects/${src}`

// Reserva la proporción (sin saltos). 'contain' por defecto: nunca recorta. zoom=true abre ampliación.
export default function Img({ img, eager = false, zoom = false }) {
  const [failed, setFailed] = useState(!img?.src)
  const [open, setOpen] = useState(false)
  useEffect(() => {
    if (!open) return
    const k = (e) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k)
  }, [open])
  if (!img) return null
  const { src, alt = '', orientation = 'vertical', ratio, fit = 'contain', position, bg, caption, credit, page } = img
  if (failed && !DEV) return null
  const pic = failed ? <span className="ph">Imagen pendiente</span> : (
    <img src={url(src)} alt={alt} loading={eager ? 'eager' : 'lazy'} decoding="async"
      style={{ objectFit: fit, objectPosition: position }} onError={() => setFailed(true)} />)
  return (
    <figure className="fig">
      <div className={`frame${page ? ' page' : ''}`} style={{ aspectRatio: ratio || RATIO[orientation] || RATIO.vertical, background: bg }}>
        {zoom && !failed ? <button className="zoom" onClick={() => setOpen(true)} aria-label="Ampliar imagen">{pic}</button> : pic}
      </div>
      {(caption || credit) && <figcaption>{caption}{credit && <span> © {credit}</span>}</figcaption>}
      {open && <div className="lb" role="dialog" aria-modal="true" onClick={() => setOpen(false)}><img src={url(src)} alt={alt} /><button aria-label="Cerrar">×</button></div>}
    </figure>
  )
}
