import { Link } from 'react-router-dom'
import Img from './Img.jsx'
export default function ProjectLink({ p, i = 0 }) {
  return (
    <Link to={`/projects/${p.slug}`} className="pl rise" style={{ "--d": `${i * 70}ms` }}>
      <Img img={p.coverImage} />
      <div className="meta"><span className="ptitle">{p.title}</span><span>{[p.year, (p.categories || []).join(', ')].filter(Boolean).join(' — ')}</span></div>
    </Link>
  )
}
