import Img from './Img.jsx'
import Reveal from './Reveal.jsx'
const Text = ({ title, body }) => (
  <div className="text">{title && <h3 className="label">{title}</h3>}
    {body && body.split('\n\n').map((p, i) => <p key={i}>{p}</p>)}</div>
)
const Row = ({ images = [], cls }) => (
  <div className={`row ${cls}`}>{images.map((im, i) => <div key={i} style={{ flex: im?.weight || 1 }}><Img img={im} zoom /></div>)}</div>
)
const MAP = {
  text: (s) => <section className="s-text"><Text {...s} /></section>,
  image: (s) => <section className="s-image" style={{ maxWidth: s.maxWidth }}><Img img={s.image} zoom /></section>,
  full: (s) => <section className="s-full"><Img img={s.image} /></section>,
  diptych: (s) => <section className="s-wide"><Row images={s.images} cls="r2" /></section>,
  triptych: (s) => <section className="s-wide"><Row images={s.images} cls="r3" /></section>,
  gallery: (s) => <section className="s-wide"><Row images={s.images} cls="gal" /></section>,
  sequence: (s) => <section className="s-seq">{(s.images || []).map((im, i) => <Img key={i} img={im} zoom />)}</section>,
  divider: (s) => <section className="s-divider"><hr />{s.text && <span className="label">{s.text}</span>}</section>,
  textImage: (s) => (
    <section className={`s-wide ti ${s.side === 'left' ? 'ti-l' : ''}`}><Text {...s} /><Img img={s.image} /></section>
  ),
}
export default function Sections({ sections = [] }) {
  return sections.map((s, i) => (MAP[s.type] ? <Reveal key={i}>{MAP[s.type](s)}</Reveal> : null))
}
