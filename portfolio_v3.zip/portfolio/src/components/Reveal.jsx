import { useEffect, useRef, useState } from 'react'
// Aparición suave al entrar en pantalla (se desactiva con prefers-reduced-motion desde CSS)
export default function Reveal({ children, as: T = 'div', delay = 0, className = '' }) {
  const r = useRef(null); const [on, setOn] = useState(false)
  useEffect(() => {
    if (!('IntersectionObserver' in window)) { setOn(true); return }
    const o = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setOn(true); o.disconnect() } }, { rootMargin: '0px 0px -8% 0px' })
    o.observe(r.current); return () => o.disconnect()
  }, [])
  return <T ref={r} className={`rv ${on ? 'in' : ''} ${className}`} style={{ transitionDelay: `${delay}ms` }}>{children}</T>
}
