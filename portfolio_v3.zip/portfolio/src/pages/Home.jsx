import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { siteConfig as c } from '../data/siteConfig.js'
import { getPublished } from '../data/projects.js'
import Img from '../components/Img.jsx'
import Reveal from '../components/Reveal.jsx'
const pad = (n) => String(n).padStart(2, '0')

function Stage({ list }) {
  const [i, setI] = useState(0); const [pause, setPause] = useState(false); const n = list.length
  useEffect(() => {
    if (pause || n < 2 || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const t = setInterval(() => setI((x) => (x + 1) % n), 4800); return () => clearInterval(t)
  }, [pause, n])
  const go = (d) => setI((i + d + n) % n)
  const p = list[i]
  return (
    <div className="stage" onMouseEnter={() => setPause(true)} onMouseLeave={() => setPause(false)} onFocus={() => setPause(true)} onBlur={() => setPause(false)}>
      <Link to={`/projects/${p.slug}`} className="stage-main" aria-label={`Ver proyecto: ${p.title}`}>
        {list.map((q, k) => <div key={q.id} className={`slide${k === i ? ' on' : ''}`} aria-hidden={k !== i}><Img img={q.coverImage} eager={k === 0} /></div>)}
      </Link>
      <div className="stage-cap">
        <span className="label">{pad(i + 1)} / {pad(n)}</span>
        <Link to={`/projects/${p.slug}`}>{p.title}</Link>
        {n > 1 && <span className="stage-ctl"><button onClick={() => go(-1)} aria-label="Anterior">←</button><button onClick={() => go(1)} aria-label="Siguiente">→</button></span>}
      </div>
    </div>
  )
}

export default function Home() {
  const all = getPublished(); const feat = all.filter((p) => p.featured)
  const stage = feat.length ? feat : all
  return (
    <>
      <section className="hero">
        <div className="hero-text">
          <p className="label">Portfolio · {c.brand}</p>
          <h1>{c.name}</h1>
          <p className="lead">{c.tagline}</p>
          {c.availability && <p className="avail"><i aria-hidden="true" />{c.availability}</p>}
        </div>
        {stage.length > 0 && <Stage list={stage} />}
      </section>
      {all.length > 0 ? (
        <section className="index" aria-label="Índice de proyectos">
          <div className="bar"><h2 className="label">Índice ({all.length})</h2><Link to="/projects" className="more">Ver todos los proyectos →</Link></div>
          {all.map((p, i) => (
            <Reveal key={p.id} delay={i * 40}>
              <Link to={`/projects/${p.slug}`} className="irow">
                <span className="num">{pad(i + 1)}</span><span className="it">{p.title}</span>
                <span className="ic">{(p.categories || []).join(' · ')}</span><span className="iy">{p.year}</span><span className="ia" aria-hidden="true">→</span>
              </Link>
            </Reveal>))}
        </section>
      ) : <p className="empty">Archivo en construcción. Nuevos proyectos próximamente.</p>}
    </>
  )
}
