import { Link } from 'react-router-dom'
import { siteConfig as c } from '../data/siteConfig.js'
import Img from '../components/Img.jsx'
import Reveal from '../components/Reveal.jsx'
const Row = ({ title, children }) => children ? <Reveal className="cvrow"><h2 className="label">{title}</h2><div>{children}</div></Reveal> : null
const tags = (a) => a?.length ? <ul className="tags">{a.map((x) => <li key={x}>{x}</li>)}</ul> : null
export function About() {
  const a = c.about
  return (
    <section className="info">
      <h1>Sobre mí</h1>
      <div className="about">
        {a.image && <div className="about-img"><Img img={a.image} eager /></div>}
        <div className="about-body">
          {a.intro && <p className="lead first">{a.intro}</p>}
          <Row title="Áreas de interés">{tags(a.areas)}</Row>
          <Row title="Formación">{a.education?.length > 0 && a.education.map((e) => <div className="item" key={e.title}><strong>{e.title}</strong><span>{e.place}</span><em>{e.years}</em></div>)}</Row>
          <Row title="Experiencia">{a.experience?.length > 0 && a.experience.map((e) => <div className="item" key={e.title}><strong>{e.title}</strong>{e.place && <span>{e.place}</span>}{e.items?.length > 0 && <ul>{e.items.map((x) => <li key={x}>{x}</li>)}</ul>}</div>)}</Row>
          <Row title="Idiomas">{a.languages?.length > 0 && a.languages.map((l) => <div className="item" key={l.name}><strong>{l.name}</strong><span>{l.level}</span></div>)}</Row>
          <Row title="Herramientas">{tags(a.tools)}</Row>
          <Row title="Aptitudes">{tags(a.skills)}</Row>
          <p className="cta"><Link to="/contact">Contacto →</Link><Link to="/projects">Ver proyectos →</Link></p>
        </div>
      </div>
    </section>
  )
}
export function Contact() {
  return (
    <section className="info">
      <h1>Contacto</h1>
      <div className="blk contact">
        {c.availability && <p className="lead">{c.availability}</p>}
        {c.email ? <p><a className="big" href={`mailto:${c.email}`}>{c.email}</a></p> : <p className="empty">Contacto próximamente.</p>}
        {c.location && <p>{c.location}</p>}
        {c.links.map((l) => <p key={l.url}><a href={l.url} target="_blank" rel="noreferrer">{l.label} ↗</a></p>)}
        <p><Link to="/projects">← Volver a proyectos</Link></p>
      </div>
    </section>
  )
}
