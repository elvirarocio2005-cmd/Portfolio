import { useState } from 'react'
import { getPublished } from '../data/projects.js'
import ProjectLink from '../components/ProjectLink.jsx'
export default function Projects() {
  const all = getPublished()
  const cats = [...new Set(all.flatMap((p) => p.categories || []))]
  const [f, setF] = useState(null)
  const list = f ? all.filter((p) => (p.categories || []).includes(f)) : all
  return (
    <>
      <div className="bar"><h1 className="label">Proyectos ({list.length})</h1>
        {cats.length > 1 && (
          <div className="filters" role="group" aria-label="Filtrar por categoría">
            <button aria-pressed={!f} onClick={() => setF(null)}>Todos</button>
            {cats.map((k) => <button key={k} aria-pressed={f === k} onClick={() => setF(k)}>{k}</button>)}
          </div>)}
      </div>
      {list.length ? <section className="grid">{list.map((p, i) => <ProjectLink key={`${f}-${p.id}`} p={p} i={i} />)}</section>
        : <p className="empty">Archivo en construcción.</p>}
    </>
  )
}
