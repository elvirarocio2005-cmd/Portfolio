import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { getPublished, getBySlug } from '../data/projects.js'
import Img from '../components/Img.jsx'
import Sections from '../components/Sections.jsx'
export default function Project() {
  const { slug } = useParams()
  const [pr, setPr] = useState(0)
  useEffect(() => {
    const f = () => { const h = document.documentElement; setPr(h.scrollTop / Math.max(1, h.scrollHeight - h.clientHeight)) }
    window.addEventListener('scroll', f, { passive: true }); return () => window.removeEventListener('scroll', f)
  }, [])
  const p = getBySlug(slug)
  if (!p) return <p className="empty">Proyecto no encontrado. <Link to="/projects">Volver a proyectos</Link></p>
  const all = getPublished(); const i = all.indexOf(p)
  const prev = all[(i - 1 + all.length) % all.length], next = all[(i + 1) % all.length]
  return (
    <article>
      <div className="progress" style={{ transform: `scaleX(${pr})` }} aria-hidden="true" />
      <nav className="crumbs" aria-label="Ruta">
        <Link to="/projects" className="back">← Proyectos</Link><span aria-hidden="true">/</span><Link to="/">Inicio</Link>
        <span className="cur" aria-current="page">{p.title}</span>
      </nav>
      <header className="phead">
        <h1>{p.title}</h1>
        <p className="label">{[p.year, (p.categories || []).join(', '), p.role].filter(Boolean).join(' — ')}</p>
        {p.shortDescription && <p className="lead">{p.shortDescription}</p>}
      </header>
      <div className="cover"><Img img={p.coverImage} eager zoom /></div>
      {p.description && <section className="s-text"><div className="text">{p.description.split('\n\n').map((t, k) => <p key={k}>{t}</p>)}</div></section>}
      <Sections sections={p.sections} />
      {p.credits?.length > 0 && <dl className="credits">{p.credits.map((c, k) => <div key={k}><dt className="label">{c.label}</dt><dd>{c.name}</dd></div>)}</dl>}
      <nav className="pn" aria-label="Más proyectos">
        {all.length > 1 && <Link to={`/projects/${prev.slug}`} className="pn-a"><span className="label">Anterior</span>{prev.title}</Link>}
        <Link to="/projects" className="pn-all">Todos los proyectos</Link>
        {all.length > 1 && <Link to={`/projects/${next.slug}`} className="pn-a pn-n"><span className="label">Siguiente</span>{next.title}</Link>}
      </nav>
    </article>
  )
}
