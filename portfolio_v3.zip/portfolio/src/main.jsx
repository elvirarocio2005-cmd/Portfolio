import React from 'react'
import { createRoot } from 'react-dom/client'
import { HashRouter } from 'react-router-dom'
import App from './App.jsx'
import { siteConfig } from './data/siteConfig.js'
import './styles/global.css'
// Tipografía de Adobe Fonts: se activa al indicar el ID del kit en siteConfig.adobeFontsKit
if (siteConfig.adobeFontsKit) {
  const l = document.createElement('link'); l.rel = 'stylesheet'
  l.href = `https://use.typekit.net/${siteConfig.adobeFontsKit}.css`; document.head.appendChild(l)
}
createRoot(document.getElementById('root')).render(<HashRouter><App /></HashRouter>)
