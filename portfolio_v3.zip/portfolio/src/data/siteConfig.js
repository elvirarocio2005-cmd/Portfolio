// Edita aquí los datos generales. Los campos vacíos no se muestran.
export const siteConfig = {
  name: 'Rocío Elvira Villullas',
  brand: 'CIRA studio',
  tagline: 'Moda, investigación e imagen. Busco prácticas en tendencias, coolhunting, fotografía, editorial, estilismo, dirección de arte y e-commerce.',
  email: 'elvirarocio2005@gmail.com',
  location: '',                       // ← p. ej. 'Valladolid'
  availability: 'Disponible para prácticas profesionales. Posibilidad de incorporación inmediata.',
  links: [],                          // ← REDES: [{ label: 'Instagram', url: 'https://instagram.com/…' }, { label: 'LinkedIn', url: '…' }, { label: 'Behance', url: '…' }]
  adobeFontsKit: '',                  // ← ID del kit de Adobe Fonts (ver INSTRUCCIONES.md)
  about: {
    intro: 'Estudiante de Diseño de Moda en Valladolid. Mi manera de trabajar combina investigación, intuición, emoción y construcción conceptual: me interesa encontrar conexiones entre referencias y convertirlas en propuestas visuales coherentes.',
    areas: ['Investigación de tendencias', 'Coolhunting', 'Fotografía', 'Editorial', 'Estilismo', 'Dirección de arte', 'E-commerce'],
    education: [
      { title: 'Grado en Diseño de Moda', place: 'Escuela Superior de Diseño de Valladolid', years: '2023 – actualidad' },
      { title: 'Bachillerato de Ciencias Sociales', place: 'IES Jorge Manrique, Palencia', years: '2021 – 2023' },
    ],
    experience: [
      { title: 'Azafata de eventos', place: 'Tamayo agencias, Ayuntamiento de Valladolid', items: ['Promotora de marcas', 'Atención al público', 'Asistente en desfiles de moda'] },
      { title: 'Maquilladora para eventos', place: '', items: ['Maquillaje a domicilio para celebraciones'] },
      { title: 'Animadora infantil', place: '', items: ['Cuidado y entretenimiento infantil'] },
    ],
    languages: [{ name: 'Castellano', level: 'Nativo' }, { name: 'Inglés', level: 'B2 (certificado por la Universidad de Cambridge)' }, { name: 'Francés', level: 'B1' }],
    tools: ['Adobe', 'Microsoft 365'],
    skills: ['Adaptabilidad', 'Comunicación', 'Trabajo en equipo', 'Compromiso', 'Productividad'],
    image: { src: '_about/retrato.jpg', alt: 'Retrato de Rocío Elvira en Callao, Madrid', ratio: '3 / 4', fit: 'cover', position: '50% 35%' },
  },
}
