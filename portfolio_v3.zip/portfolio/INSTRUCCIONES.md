# Cómo usar y actualizar el portfolio

## Ejecutar
```
npm install
npm run dev      # desarrollo (http://localhost:5173), muestra el proyecto DEMO y marcadores de imagen
npm run build    # genera /dist para publicar (Netlify, Vercel, GitHub Pages, Cloudflare Pages…)
```
La web usa rutas con `#`, así que funciona en cualquier hosting estático sin configuración.

## Datos personales
Edita `src/data/siteConfig.js` (nombre, correo, ubicación, disponibilidad, enlaces, About).
Los campos vacíos no se muestran.

## Añadir un proyecto
1. Crea `public/projects/mi-proyecto/` y guarda ahí tus imágenes optimizadas (JPG/WebP, ~2000 px el lado largo).
2. En `src/data/projects.js` copia el objeto `plantilla` y rellena `id`, `slug` (único, sin espacios), `title`, `coverImage`.
3. Añade textos y `sections` cuando los tengas. Con solo título + portada ya funciona.
4. Cambia `status: 'draft'` a `status: 'published'` para publicarlo. `draft` = oculto.
5. `npm run build` y sube `dist/`.

Rutas de imagen: relativas a `public/projects/` → `src: 'mi-proyecto/01.jpg'`.

## Tipos de sección (el orden del array es el orden en la página)
`text`, `image`, `full` (a sangre), `diptych`, `triptych`, `gallery`, `divider`, `textImage` (`side:'left'|'right'`), `sequence`.

## Imágenes
Campos: `src, alt, orientation ('vertical'|'horizontal'|'square'), ratio ('3/4'…), caption, credit, weight (1–3), fit, position, bg`.
- Por defecto NUNCA se recorta (`fit:'contain'`). Para recortar a mano: `fit:'cover', position:'50% 20%'`.
- `ratio` debe coincidir con la foto real para evitar bandas; `bg:'#000'` da fondo negro.
- `alt` es obligatorio por accesibilidad.
- Si falta un archivo: en desarrollo verás "Imagen pendiente"; en la web publicada no aparece nada.

## Categorías
Se escriben libremente en `categories` del proyecto. El filtro solo muestra las que están en uso.

## Proyectos actuales
Los seis proyectos se generaron a partir de tus PDF: cada página es una imagen en `public/projects/<slug>/NN.jpg` (clic para ampliar).
Para sustituir páginas por fotografías originales de mayor calidad, cambia el archivo conservando el nombre, o edita `ratio` y `src` en `projects.js`.
Revisa títulos y textos de cada proyecto (sobre todo «Investigación PDM IV»). Para ocultar uno: `status: 'draft'`.

## Cambios de la v3
- **Logotipo y favicon**: `public/logo.png` (espiral), `public/brand.png` («CIRA studio») y `public/favicon.png`, recortados de tu tarjeta. Para cambiarlos, sustituye esos archivos manteniendo el nombre.
- **Redes y pie de página**: edita `links` en `src/data/siteConfig.js`; aparecen en el pie y en Contacto.
- **Sobre mí**: se rellena desde `siteConfig.about` (formación, experiencia, idiomas, herramientas, aptitudes).
- **Tipografía de Adobe Fonts**: entra en fonts.adobe.com, crea un proyecto web, añade la familia **Neue Haas Unica**, copia el ID del kit (la parte de `https://use.typekit.net/XXXXXXX.css`) y pégalo en `adobeFontsKit`. Tienes que añadir tu dominio de publicación a ese proyecto. Sin ID se usa Helvetica/Arial.
